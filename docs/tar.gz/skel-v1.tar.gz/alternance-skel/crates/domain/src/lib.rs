//! Domaine métier — entités pures, sans dépendance infra.
//!
//! Ce crate ne dépend ni de tokio, ni de sqlx, ni de reqwest. Si vous y voyez
//! arriver une de ces dépendances, c'est qu'une responsabilité s'est mal
//! placée — il faut la déplacer dans `application` ou un `adapter`.

pub mod ids;
pub mod offre;
pub mod profil;
pub mod chunk;
pub mod instance;
pub mod errors;

pub use ids::*;
pub use offre::*;
pub use profil::*;
pub use chunk::*;
pub use instance::*;
pub use errors::*;
